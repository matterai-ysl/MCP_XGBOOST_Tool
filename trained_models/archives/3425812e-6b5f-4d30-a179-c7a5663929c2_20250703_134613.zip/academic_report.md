# XGBoost Training Report

**Generated on:** 2025-07-03 13:46:13  
**Model ID:** `3425812e-6b5f-4d30-a179-c7a5663929c2`  
**Model Folder:** `trained_models\3425812e-6b5f-4d30-a179-c7a5663929c2`

## Executive Summary

This report documents a comprehensive XGBoost training experiment conducted for academic research and reproducibility purposes. The experiment involved hyperparameter optimization and cross-validated model training with detailed performance analysis, data validation, and feature importance evaluation.

### Key Results
### 🎯 关键性能指标

- **准确率 (Accuracy):** 0.960000 (±0.024944)
- **F1分数 (F1 Score):** 0.959832 (±0.025080)
- **精确率 (Precision):** 0.963434 (±0.023161)
- **召回率 (Recall):** 0.960000 (±0.024944)

- **交叉验证折数:** 5
- **数据集规模:** 150 样本, 4 特征

### ⚙️ 最优超参数

- **n_estimators:** 80
- **max_depth:** 7
- **learning_rate:** 0.07169637569085559
- **subsample:** 0.8900646198797657
- **colsample_bytree:** 0.6023139893373228
- **colsample_bylevel:** 0.9604520312917825
- **reg_alpha:** 8.248331500575938e-07
- **reg_lambda:** 5.3195620076571505e-05
- **min_child_weight:** 2
- **gamma:** 0.2787377387032074

- **训练时间:** 591.55 秒

---

## 1. Experimental Setup

### 1.1 Dataset Information

| Parameter | Value |
|-----------|-------|
| Data Shape | {'n_samples': 150, 'n_features': 4} |
| Number of Targets | 1 |

### 1.2 Training Configuration

| Parameter | Value |
|-----------|-------|
| Task Type | Classification |

### 1.3 Hardware and Software Environment

- **Python Version:** 3.8+
- **Machine Learning Framework:** XGBoost, scikit-learn
- **Data Processing:** pandas, numpy
- **Hyperparameter Optimization:** Optuna
- **Device:** CPU

---

## 2. Data Processing and Validation

### 2.1 Data Loading and Initial Inspection

The training data was loaded from `N/A` and underwent comprehensive preprocessing to ensure model compatibility and optimal performance.

**Input Features (N/A columns):**
`sepal_length`, `sepal_width`, `petal_length`, `petal_width`

**Target Variables (1 column):**
`class`


### 2.4 Data Quality Assessment

Comprehensive data validation was performed using multiple statistical methods to ensure dataset quality and suitability for machine learning model training. The validation framework employed established statistical techniques for thorough data quality assessment.

#### 2.4.1 Overall Quality Metrics

| Metric | Value | Threshold | Interpretation |
|--------|-------|-----------|----------------|
| Overall Data Quality Score | 87.5/100 | ≥80 (Excellent), ≥60 (Good) | Good - Meets academic standards |
| Quality Level | Good | - | Categorical assessment |
| Ready for Training | Yes | Yes | Model training readiness |
| Critical Issues | 2 | 0 | Data integrity problems |
| Warnings | 0 | <5 | Minor data quality concerns |

#### 2.4.2 Validation Methodology and Results

| Check Name | Method Used | Status | Issues Found | Key Findings |
|------------|-------------|--------|-------------|-------------|
| Feature Names | Statistical Analysis | ✅ PASSED | 0 | No issues |
| Data Dimensions | Statistical Analysis | ✅ PASSED | 0 | No issues |
| Target Variable | Statistical Analysis | ✅ PASSED | 0 | No issues |
| Data Leakage | Statistical Analysis | ✅ PASSED | 0 | No issues |
| Sample Balance | Chi-square, Gini coefficient | ✅ PASSED | 0 | Balanced; ratio=0.333 |
| Feature Correlations | Pearson/Spearman/Kendall | ✅ PASSED | 1 | 3 high correlations |
| Multicollinearity Detection | Variance Inflation Factor (VIF) | ❌ FAILED | 2 | 3 high VIF; avg=14.19 |
| Feature Distributions | Shapiro-Wilk, Jarque-Bera, D'Agostino | ✅ PASSED | 2 | 2 distribution issues |


#### 2.4.2.4 Sample Balance Analysis

**Methodology**: Chi-square goodness-of-fit test and Gini coefficient calculation for class distribution assessment.

**Results**:
- Minority class ratio: 0.3333
- Dataset balance: Balanced
- Number of classes: 3

**Class Distribution**:
| Class | Count | Proportion | Cumulative % |
|-------|-------|------------|-------------|
| Iris-setosa | 0.3333333333333333 | 0.3333 | 33.3% |
| Iris-versicolor | 0.3333333333333333 | 0.3333 | 66.7% |
| Iris-virginica | 0.3333333333333333 | 0.3333 | 100.0% |


**Methodological Implications**: Balanced class distribution supports unbiased model training and reliable performance metrics.

#### 2.4.2.1 Feature Correlation Analysis

**Methodology**: Pearson, Spearman, and Kendall correlation coefficients were computed for all feature pairs. The correlation threshold was set at |r| ≥ 0.7.

**Results**: 3 feature pairs exceeded the correlation threshold, indicating potential redundancy in the feature space.

**Feature Classification**:
Continuous Features: sepal_length, sepal_width, petal_length, petal_width
Categorical Features: None
Target Feature: class

**Statistical Findings**:
**Continuous Features vs Continuous Features Correlation Analysis (Pearson Correlation Coefficient)**:

| Feature 1 | Feature 2 | Correlation | Absolute Value |
|-----------|-----------|-------------|----------------|
| petal_length | petal_width | 0.9628 | 0.9628 |
| sepal_length | petal_length | 0.8718 | 0.8718 |
| sepal_length | petal_width | 0.8180 | 0.8180 |
| sepal_width | petal_length | -0.4205 | 0.4205 |
| sepal_width | petal_width | -0.3565 | 0.3565 |
| sepal_length | sepal_width | -0.1094 | 0.1094 |


**Continuous Features vs Continuous Features Correlation Analysis (Spearman's Rank Correlation)**:

| Feature 1 | Feature 2 | Correlation | Absolute Value |
|-----------|-----------|-------------|----------------|
| petal_length | petal_width | 0.9360 | 0.9360 |
| sepal_length | petal_length | 0.8814 | 0.8814 |
| sepal_length | petal_width | 0.8344 | 0.8344 |
| sepal_width | petal_length | -0.3034 | 0.3034 |
| sepal_width | petal_width | -0.2775 | 0.2775 |
| sepal_length | sepal_width | -0.1595 | 0.1595 |


**Continuous Features vs Target Variable Correlation Analysis**:

| Feature | Correlation | Method | Absolute Value | Strength |
|---------|-------------|--------|----------------|----------|
| petal_length | 0.9350 | correlation_ratio | 0.9350 | Strong |
| petal_width | 0.9226 | correlation_ratio | 0.9226 | Strong |
| sepal_length | 0.6146 | correlation_ratio | 0.6146 | Moderate |
| sepal_width | 0.3893 | correlation_ratio | 0.3893 | Weak |


**Impact Assessment**: High feature correlation may lead to multicollinearity issues and reduced model interpretability.

#### 2.4.2.2 Multicollinearity Detection

**Methodology**: Variance Inflation Factor (VIF) analysis was conducted using linear regression. VIF values ≥ 5.0 indicate problematic multicollinearity.

**Results**: 
- Average VIF: 14.185
- Maximum VIF: 31.397
- Features with VIF ≥ 5.0: 3

**Statistical Findings**:
**VIF Scores for All Features**:

| Feature | VIF Score | R² | Interpretation | Status |
|---------|-----------|----|--------------|---------|
| petal_length | 31.3973 | 0.9682 | Severe | ⚠️ HIGH |
| petal_width | 16.1416 | 0.9380 | Severe | ⚠️ HIGH |
| sepal_length | 7.1031 | 0.8592 | Moderate | ⚠️ MODERATE |
| sepal_width | 2.0990 | 0.5236 | Acceptable | ✅ LOW |


**Methodological Impact**: Elevated VIF scores suggest linear dependencies between predictors, which may compromise model stability and coefficient interpretation.

#### 2.4.2.3 Feature Distribution Analysis

**Methodology**: 
- Continuous features: Shapiro-Wilk test (n≤5000), Jarque-Bera test (n≥50), D'Agostino test (n≥20) for normality
- Skewness assessment using sample skewness coefficient
- Outlier detection via Interquartile Range (IQR) method
- Categorical features: Gini coefficient, entropy, and class imbalance ratio analysis

**Results**: 0 distribution-related issues identified across 7 continuous and 0 categorical features.

**Continuous Features Statistical Summary**:
| Feature | mean | std | min | max | max | median | Skewness | Kurtosis | Normality | Outliers (%) | Issues |
|---------|----------|---------|----------|---------|----------|---------|----------|-----------|-------------|--------|
| petal_length | 3.759 | 1.764 | 1.000 | 6.900 | 6.900 | 4.350 | -0.272 | -1.395 | No | 0.0% | 1 |
| petal_width | 1.199 | 0.763 | 0.100 | 2.500 | 2.500 | 1.300 | -0.104 | -1.335 | No | 0.0% | 1 |
| sepal_length | 5.843 | 0.828 | 4.300 | 7.900 | 7.900 | 5.800 | 0.312 | -0.574 | No | 0.0% | 0 |
| sepal_width | 3.054 | 0.434 | 2.000 | 4.400 | 4.400 | 3.000 | 0.331 | 0.241 | Yes | 2.7% | 0 |

**Continuous Feature Distribution Issues:**
- Feature 'petal_length' significantly deviates from normal distribution
- Feature 'petal_width' significantly deviates from normal distribution


**Categorical Features Statistical Summary**:
No categorical features analyzed.

**Distribution Quality Impact**: Feature distributions meet statistical assumptions for machine learning applications.

#### 2.4.2.5 Statistical Summary

**Validation Framework Performance**:
- Total validation checks: 8
- Passed checks: 7 (87.5%)
- Failed checks: 1

**Data Quality Confidence**: Based on the comprehensive validation framework, the dataset demonstrates high statistical reliability for machine learning applications.

#### 2.4.3 Data Quality Issues and Impact Assessment

**Critical Issues Identified:**

- Detected 3 features with high VIF (>= 5.0)
- Found 3 highly correlated feature pairs

**Data Quality Recommendations:**

1. Investigate high correlations and consider feature selection
2. Resolve multicollinearity using VIF-guided feature selection or regularization


#### 2.4.4 Academic and Methodological Implications

The data validation results indicate that the dataset meets the quality standards required for academic machine learning research. Moderate data quality with some limitations. Results should be interpreted with consideration of identified data quality issues.

**Reproducibility Impact**: High reproducibility confidence with comprehensive data quality documentation supporting experimental replication.


### 2.2 Data Preprocessing Pipeline

The data underwent comprehensive preprocessing to optimize model performance and ensure consistent data quality.

#### 2.2.1 Feature Preprocessing

**Preprocessing Method**: StandardScaler (Z-score normalization)

```python
# Feature transformation: X_scaled = (X - μ) / σ
# Where μ = mean, σ = standard deviation
X_scaled = (X - X.mean(axis=0)) / X.std(axis=0)
```

**Preprocessing Benefits:**
- **Feature Consistency**: Normalizes different scales and units
- **Algorithm Optimization**: Improves convergence for distance-based methods
- **Numerical Stability**: Prevents overflow/underflow in computations
- **Cross-Validation Integrity**: Separate scaling per fold prevents data leakage

### 2.3 Feature Engineering

### 2.3 Feature Selection and Engineering

#### 2.3.1 Feature Selection Strategy

**Approach**: Comprehensive feature utilization

XGBoost inherently performs feature selection during the training of boosted trees. Key mechanisms include:
- **Greedy Search**: At each split, the algorithm selects the feature and split point that maximize the gain.
- **Regularization**: L1 (Lasso) and L2 (Ridge) regularization penalize complex models, effectively shrinking the coefficients of less important features.
- **Feature Importance Calculation**: XGBoost provides multiple metrics (gain, weight, cover) to score feature relevance automatically.

#### 2.3.2 Feature Engineering Pipeline

**Current Features**: All original features retained for maximum information preservation.
**Categorical Encoding**: Best practice is to one-hot encode categorical features for XGBoost.
**Missing Value Strategy**: XGBoost has a built-in, optimized routine to handle missing values by learning a default direction for them at each split.
**Feature Interaction**: Captured implicitly and explicitly through the tree-based structure of the model.


---

## 3. Hyperparameter Optimization

### 3.1 Hyperparameter Search Space

The optimization process systematically explored a comprehensive parameter space designed to balance model complexity and performance:

| Parameter | Range/Options | Description |
|-----------|---------------|-------------|
| n_estimators | 50-150 (step: 10) | Number of boosting rounds (trees) in the ensemble |
| max_depth | 1-10 (step: 1) | Maximum depth of each tree in the ensemble |
| learning_rate | 0.01-0.3 (log scale) | Step size shrinkage to prevent overfitting |
| subsample | 0.6-1.0 (linear scale) | Fraction of samples used for training each tree |
| colsample_bytree | 0.6-1.0 (linear scale) | Fraction of features used for training each tree |
| colsample_bylevel | 0.6-1.0 (linear scale) | Fraction of features used for each level in each tree |
| reg_alpha | 1e-08-10.0 (log scale) | L1 regularization term on weights (Lasso regularization) |
| reg_lambda | 1e-08-10.0 (log scale) | L2 regularization term on weights (Ridge regularization) |
| min_child_weight | 1-10 (step: 1) | Minimum sum of instance weight needed in a child node |
| gamma | 1e-08-10.0 (log scale) | Minimum loss reduction required to make a split |

### 3.2 Optimization Algorithm and Strategy

**Algorithm**: TPE (Tree-structured Parzen Estimator)
**Total Trials**: 50
**Completed Trials**: 50
**Best Score**: 0.959832

**Optimization Strategy:**
- **Initial Exploration**: 10 random trials for space exploration
- **Exploitation-Exploration Balance**: TPE algorithm balances promising regions with unexplored space
- **Cross-Validation**: Each trial evaluated using stratified k-fold cross-validation
- **Early Stopping**: Poor-performing trials terminated early to improve efficiency

### 3.3 Best Parameters Found

```json
{
  "n_estimators": 80,
  "max_depth": 7,
  "learning_rate": 0.07169637569085559,
  "subsample": 0.8900646198797657,
  "colsample_bytree": 0.6023139893373228,
  "colsample_bylevel": 0.9604520312917825,
  "reg_alpha": 8.248331500575938e-07,
  "reg_lambda": 5.3195620076571505e-05,
  "min_child_weight": 2,
  "gamma": 0.2787377387032074
}
```

### 3.4 Optimization Convergence

The optimization process completed **50 trials** with the best configuration achieving a cross-validation score of **0.959832**.

**Key Optimization Insights:**
- **Ensemble Size**: 80 boosting rounds balances performance and computational efficiency
- **Tree Complexity**: Maximum depth of 7 controls model complexity and overfitting
- **Learning Rate**: 0.07169637569085559 provides optimal step size for gradient descent
- **Regularization**: L1=8.25e-07, L2=5.32e-05 prevent overfitting
- **Sampling**: 0.8900646198797657 row sampling and 0.6023139893373228 column sampling for robustness

## 4. Final Model Training

### 4.1 Cross-Validation Training

The final model was trained using 5-fold cross-validation with optimized hyperparameters. Training metrics and validation results were recorded comprehensively.

### 4.2 Training Results

| Metric | Value |
|--------|-------|
### Cross-Validation Performance Metrics

| Metric | Mean ± Std | Min | Max |
|--------|------------|-----|-----|
| ACCURACY | 0.960000 ± 0.024944 | 0.933333 | 1.000000 |
| F1 | 0.959832 ± 0.025080 | 0.932660 | 1.000000 |
| PRECISION | 0.963434 ± 0.023161 | 0.933333 | 1.000000 |
| RECALL | 0.960000 ± 0.024944 | 0.933333 | 1.000000 |



#### Fold-wise Results

#### Detailed Fold-wise Performance

| Fold | ACCURACY | F1 | PRECISION | RECALL |
|------|---------|---------|---------|---------|
| 1 | 0.966667 | 0.966583 | 0.969697 | 0.966667 |
| 2 | 0.966667 | 0.966583 | 0.969697 | 0.966667 |
| 3 | 0.933333 | 0.932660 | 0.944444 | 0.933333 |
| 4 | 1.000000 | 1.000000 | 1.000000 | 1.000000 |
| 5 | 0.933333 | 0.933333 | 0.933333 | 0.933333 |

#### Statistical Summary

| Metric | Mean | Std Dev | Min | Max | 95% CI |
|--------|------|---------|-----|-----|--------|
| ACCURACY | 0.960000 | 0.024944 | 0.933333 | 1.000000 | [0.938135, 0.981865] |
| F1 | 0.959832 | 0.025080 | 0.932660 | 1.000000 | [0.937848, 0.981816] |
| PRECISION | 0.963434 | 0.023161 | 0.933333 | 1.000000 | [0.943133, 0.983736] |
| RECALL | 0.960000 | 0.024944 | 0.933333 | 1.000000 | [0.938135, 0.981865] |

### 4.3 Model Performance Visualization

#### Classification Performance Analysis

The cross-validation analysis demonstrates the model's classification performance through ROC curves showing the trade-off between true positive rate and false positive rate.

<div style="text-align: center; margin: 20px 0;">
    <img src="cross_validation_data/cross_validation_roc_curves.png" alt="Cross-Validation ROC Curves" style="max-width: 100%; height: auto; border-radius: 8px; box-shadow: 0 4px 8px rgba(0,0,0,0.1);">
    <p style="font-style: italic; color: #666; margin-top: 10px;">Cross-Validation ROC Curves</p>
</div>



### 4.4 Feature Importance Analysis

#### Feature Importance Analysis

This analysis employs multiple methodologies to comprehensively evaluate feature importance in the XGBoost model:

**Analysis Methods:**

1. **Built-in Importance (Gain, Cover, Weight)**:
   - **Gain**: The average training loss reduction gained when a feature is used for splitting. It is the most common and relevant metric.
   - **Cover**: The average number of samples affected by splits on this feature.
   - **Weight**: The number of times a feature is used to split the data across all trees.

2. **Permutation Importance**:
   - Model-agnostic method measuring feature contribution to model performance
   - Evaluates performance drop when feature values are randomly shuffled
   - More reliable for correlated features and unbiased feature ranking
   - Computed on out-of-sample data to avoid overfitting

**XGBoost Tree-based Feature Importance:**

| Rank | Feature | Gain | Weight | Cover | Gain % | Weight % |
|------|---------|------|--------|-------|--------|----------|
| 1 | `petal_width` | 7.0775 | 109 | 22.98 | 39.0% | 26.6% |
| 2 | `petal_length` | 5.6158 | 113 | 21.85 | 31.0% | 27.6% |
| 3 | `sepal_length` | 4.0260 | 109 | 28.24 | 22.2% | 26.6% |
| 4 | `sepal_width` | 1.4131 | 79 | 26.07 | 7.8% | 19.3% |


**Permutation Feature Importance:**

| Rank | Feature | Mean Importance | Std Dev | 95% CI | Reliability |
|------|---------|-----------------|---------|--------|-------------|
| 1 | `petal_width` | 0.0827 | 0.0191 | [0.0452, 0.1202] | 🟡 Medium |
| 2 | `petal_length` | 0.0720 | 0.0148 | [0.0429, 0.1011] | 🟡 Medium |
| 3 | `sepal_length` | 0.0027 | 0.0033 | [-0.0037, 0.0091] | 🔴 Low |
| 4 | `sepal_width` | -0.0013 | 0.0027 | [-0.0066, 0.0039] | 🔴 Low |


**Feature Importance Method Comparison:**

| Feature | XGB Gain Rank | Permutation Rank | Rank Difference | Consistency |
|---------|---------------|------------------|-----------------|-------------|
| `sepal_length` | 3 | 3 | 0 | 🟢 Excellent |
| `sepal_width` | 4 | 4 | 0 | 🟢 Excellent |
| `petal_length` | 2 | 2 | 0 | 🟢 Excellent |
| `petal_width` | 1 | 1 | 0 | 🟢 Excellent |


**Statistical Summary:**

- **Total Features Analyzed**: 4
- **Gain-based Top Feature**: `petal_width` (Gain: 7.0775)
- **Permutation-based Top Feature**: `petal_width` (Importance: 0.0827)

**Method Reliability Assessment:**
- **Average Permutation Std**: 0.0100
- **Method Agreement**: High

**Feature Importance Visualizations:**

![Feature Importance Comparison](feature_importance_comparison.png)

**Method Comparison Plot**: `feature_importance_comparison.png`

![Permutation Feature Importance](feature_importance_permutation.png)

**Permutation Importance Plot**: `feature_importance_permutation.png`

![Tree-based Feature Importance](feature_importance_tree.png)

**Tree-based Importance Plot**: `feature_importance_tree.png`

**Feature Importance Data Files:**

- `feature_importance.csv` - Detailed feature importance scores and statistics

**Statistical Interpretation:**

- **Threshold Selection**: Features with importance > 1/n_features are considered significant
- **Cumulative Importance**: Top features typically capture 80-90% of total importance
- **Stability Assessment**: Low standard deviation in permutation importance indicates reliable features
- **Domain Validation**: Feature rankings should align with domain knowledge and expectations

**Technical Implementation Notes:**

- Tree-based importance computed using XGBoost's `feature_importances_` attribute or `get_score()` method.
- Permutation importance calculated with 10 repetitions for statistical robustness
- Random state fixed for reproducible permutation results
- Analysis performed on validation data to avoid overfitting bias


---

## 5. Model Architecture and Configuration

### 5.1 XGBoost Configuration

The final model uses an XGBoost gradient boosting ensemble with the following specifications:

| Component | Configuration |
|-----------|---------------|
| Booster | gbtree (tree-based model) |

### 5.2 Training Parameters

| Parameter | Value |
|-----------|-------|
| Task Type | Classification |

---

## 6. Conclusions and Future Work

### 6.1 Key Findings

2. **Hyperparameter Optimization**: Systematic optimization improved model performance

### 6.2 Reproducibility

This experiment is fully reproducible using the following artifacts:
- **Cross-Validation Data**: `trained_models\3425812e-6b5f-4d30-a179-c7a5663929c2/cross_validation_data/`
- **Feature Importance**: `trained_models\3425812e-6b5f-4d30-a179-c7a5663929c2/feature_importance.csv`

### 6.3 Technical Implementation

- **Framework**: XGBoost for gradient boosting implementation, scikit-learn for pipeline integration.
- **Data Processing**: pandas and numpy for data handling.
- **Cross-Validation**: K-fold cross-validation with stratification support for classification.
- **Feature Importance**: Built-in XGBoost feature importance calculation (Gain, Cover, Weight).
- **Serialization**: Joblib or Pickle for model and preprocessor persistence.

---

## Appendix

### A.1 System Information

- **Generation Time**: 2025-07-03 13:46:13
- **Model ID**: `3425812e-6b5f-4d30-a179-c7a5663929c2`
- **Training System**: XGBoost MCP Tool
- **Report Version**: 2.1 (XGBoost Enhanced)

### A.2 File Structure

```
3425812e-6b5f-4d30-a179-c7a5663929c2/
├── model.joblib
├── preprocessing_pipeline.pkl
├── evaluation_metrics.csv
├── feature_importance.csv
├── optimization_history.csv
├── raw_data.csv
├── continuous_feature_distributions.png
├── continuous_feature_normality.png
├── continuous_feature_outliers.png
├── continuous_feature_violin_plots.png
├── continuous_pearson_correlation.png
├── continuous_spearman_correlation.png
├── feature_importance_comparison.png
├── feature_importance_permutation.png
├── feature_importance_tree.png
├── feature_target_continuous_correlation.png
├── vif_scores.png
├── vif_threshold_analysis.png
├── cross_validation_results.json
├── data_validation_report.json
├── feature_importance_analysis.json
├── hyperparameter_optimization.json
├── metadata.json
├── preprocessing_info.json
├── training_report.json
├── training_summary.json
├── cross_validation_data/
│   ├── 3425812e-6b5f-4d30-a179-c7a5663929c2_cv_predictions_original.csv
│   ├── 3425812e-6b5f-4d30-a179-c7a5663929c2_cv_predictions_processed.csv
│   ├── 3425812e-6b5f-4d30-a179-c7a5663929c2_original_data.csv
│   ├── 3425812e-6b5f-4d30-a179-c7a5663929c2_preprocessed_data.csv
│   ├── 3425812e-6b5f-4d30-a179-c7a5663929c2_roc_curves.png
│   ├── cross_validation_roc_curves.png
│   ├── cross_validation_visualization.png
└── academic_report.md               # This report
```

### A.3 Data Files and JSON Artifacts

The following JSON files contain detailed intermediate data for reproducibility:

- **Feature Importance**: `trained_models\3425812e-6b5f-4d30-a179-c7a5663929c2/feature_importance.csv`

---

*This report was automatically generated by the Enhanced XGBoost MCP Tool for academic research and reproducibility purposes.*
