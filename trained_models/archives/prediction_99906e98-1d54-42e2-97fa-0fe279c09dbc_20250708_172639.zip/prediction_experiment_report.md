# Prediction Experiment Report

**Generated on:** 2025-07-08 17:26:39  
**Experiment Name:** 99906e98-1d54-42e2-97fa-0fe279c09dbc  
**Model ID:** `69e194df-89e7-47d2-894c-6a9903138a81`  
**Output Directory:** `trained_models/69e194df-89e7-47d2-894c-6a9903138a81/predictions/99906e98-1d54-42e2-97fa-0fe279c09dbc`

## Executive Summary

This report documents a comprehensive machine learning prediction experiment conducted using a pre-trained regression model. The experiment involved preprocessing input data, making predictions, and providing detailed statistical analysis of the prediction results.

### Key Results
- **Number of Predictions:** 1
- **Feature Count:** 4
- **Target Count:** 1
- **Model Type:** Regression
- **Processing Time:** 0.604 seconds

---

## 1. Experiment Setup

### 1.1 Input Data Information

| Parameter | Value |
|-----------|-------|
| Number of Samples | 1 |
| Number of Features | 4 |
| Number of Targets | 1 |
| Data Shape | N/A |
| Data Type | Numerical (floating-point) |
| Preprocessing Applied | No |

### 1.2 Feature Information

**Input Features (4 columns):**
`SiO2`, `CeO2`, `lignin`, `vinyl`

**Target Variables (1 column):**
`target`

### 1.3 Model Information

| Component | Details |
|-----------|---------|
| **Model Type** | Regression Model |
| **Model ID** | `69e194df-89e7-47d2-894c-6a9903138a81` |
| **Framework** | XGBoost (scikit-learn interface) |
| **Prediction Method** | Ensemble averaging of boosted trees |

---

## 2. Prediction Results

### 2.1 Prediction Statistics


#### Single Target Prediction Statistics

**Target: target**

| Statistic | Value |
|-----------|-------|
| Mean Prediction | 0.615343 |
| Standard Deviation | 0.000000 |
| Minimum Prediction | 0.615343 |
| Maximum Prediction | 0.615343 |
| Prediction Range | 0.000000 |
| Median | 0.615343 |
| 25th Percentile | 0.615343 |
| 75th Percentile | 0.615343 |


---

## 3. Generated Files

| File | Description |
|------|-------------|
| `01_original_data.csv` | Original input data as provided |
| `02_processed_features.csv` | Features after preprocessing/normalization |
| `03_predictions_processed_scale.csv` | Predictions in processed/normalized scale |
| `04_predictions_original_scale.csv` | Predictions transformed back to original scale |
| `05_confidence_scores.csv` | Confidence/uncertainty scores for each prediction |
| `06_combined_results.csv` | All data combined: features + predictions + confidence |
| `prediction_experiment_report.md` | This detailed experiment report |
| `prediction_report.html` | Interactive HTML report |

---

## 4. Detailed Prediction Results

This section provides a comprehensive view of each prediction with corresponding input features and confidence scores.

### Feature Values and Predictions

| Sample | SiO2 | CeO2 | lignin | vinyl | Prediction | Confidence |
|--------|--------|--------|--------|--------|-----------|----------|
| **#1** | 34.000 | 9.900 | 5.500 | 4.000 | 4.2869 | 0.999 |

### Interpretation Guide

- **Prediction Values**: Continuous numerical predictions representing the target variable
- **Confidence Scores**: Range from 0.0 (low confidence) to 1.0 (high confidence)
  - **≥0.8**: High confidence - Very reliable predictions
  - **0.5-0.8**: Medium confidence - Moderately reliable
  - **<0.5**: Low confidence - Review recommended


---

## 5. Confidence Analysis

### 5.1 Confidence Calculation Method

**Regression Confidence Calculation:**
- **Primary Method**: Prediction variance across individual trees in XGBoost ensemble
- **Formula**: `confidence = 1 / (1 + variance_across_trees)`
- **Range**: 0-1, where higher values indicate more confident predictions
- **Multi-target Handling**: For models with multiple targets, confidence is averaged across all targets
- **Fallback Method**: For non-ensemble models, uses inverse relationship with prediction magnitude

**Technical Details:**
- Each tree in the XGBoost ensemble makes an independent prediction
- Variance across these individual predictions indicates uncertainty
- Low variance (trees agree) → High confidence
- High variance (trees disagree) → Low confidence

### 5.2 Confidence Statistics

**Mean Confidence:** 0.999  
**Standard Deviation:** 0.000  
**Min Confidence:** 0.999  
**Max Confidence:** 0.999  

### 5.3 Confidence Distribution

| Confidence Level | Count | Percentage | Description |
|------------------|-------|------------|-------------|
| High (≥0.8) | 1 | 100.0% | Very reliable predictions |
| Medium (0.5-0.8) | 0 | 0.0% | Moderately reliable predictions |
| Low (<0.5) | 0 | 0.0% | Uncertain predictions - review recommended |

### 5.4 Confidence Interpretation Guide

**For Regression Models:**
- **High Confidence (≥0.8)**: Trees in ensemble show strong agreement
- **Medium Confidence (0.5-0.8)**: Moderate agreement, reliable for most applications
- **Low Confidence (<0.5)**: High prediction variance, may indicate:
  - Input data outside training distribution
  - Insufficient training data for similar cases
  - High inherent noise in target variable
  - Model complexity mismatch with data complexity



---

*Report generated on 2025-07-08 17:26:39*
*MCP XGBoost Tool - Prediction Experiment Report*
