# XGBoost Training Report

**Generated on:** 2025-07-06 00:42:03  
**Model ID:** `9063132f-77f6-4bff-92d1-075c8280fd57`  
**Model Folder:** `trained_models\9063132f-77f6-4bff-92d1-075c8280fd57`

## Executive Summary

This report documents a comprehensive XGBoost training experiment conducted for academic research and reproducibility purposes. The experiment involved hyperparameter optimization and cross-validated model training with detailed performance analysis, data validation, and feature importance evaluation.

### Key Results
### 🎯 关键性能指标

- **R²分数 (R² Score):** 0.893990 (±0.022979)
- **平均绝对误差 (Mean Absolute Error):** 0.255073 (±0.027165)
- **均方误差 (Mean Squared Error):** 0.099230 (±0.017944)

- **交叉验证折数:** 5
- **数据集规模:** 53 样本, 4 特征

### ⚙️ 最优超参数

- **n_estimators:** 70
- **max_depth:** 8
- **learning_rate:** 0.29283225933783363
- **subsample:** 0.8824879580256776
- **colsample_bytree:** 0.8804650381575039
- **colsample_bylevel:** 0.9862778301767895
- **reg_alpha:** 0.0004686094248233635
- **reg_lambda:** 3.841105485827389e-06
- **min_child_weight:** 2
- **gamma:** 1.1415897581582742e-08

- **训练时间:** 340.54 秒

---

## 1. Experimental Setup

### 1.1 Dataset Information

| Parameter | Value |
|-----------|-------|
| Data Shape | {'n_samples': 53, 'n_features': 4} |
| Number of Targets | 1 |

### 1.2 Training Configuration

| Parameter | Value |
|-----------|-------|
| Task Type | Regression |

### 1.3 Hardware and Software Environment

- **Python Version:** 3.8+
- **Machine Learning Framework:** XGBoost, scikit-learn
- **Data Processing:** pandas, numpy
- **Hyperparameter Optimization:** Optuna
- **Device:** CPU

---

## 2. Data Processing and Validation

### 2.1 Data Loading and Initial Inspection

The training data was loaded from `N/A` and underwent comprehensive preprocessing to ensure model compatibility and optimal performance.

**Input Features (N/A columns):**
`SiO2`, `CeO2`, `lignin`, `vinyl`

**Target Variables (1 column):**
`TS-BF`


### 2.4 Data Quality Assessment

**Status**: No comprehensive validation performed

Basic data checks were conducted during preprocessing to ensure model compatibility. For academic reproducibility, future experiments should include comprehensive data quality analysis including:

- Missing value assessment and handling strategies
- Outlier detection using statistical methods (IQR, Z-score)
- Feature correlation analysis (Pearson, Spearman, Kendall)
- Multicollinearity detection using Variance Inflation Factor (VIF)
- Feature distribution analysis (normality tests, skewness evaluation)
- Sample balance verification for classification tasks

**Recommendation**: Enable data validation (`validate_data=True`) in future training runs to ensure data quality standards for academic publication and experimental reproducibility.


### 2.2 Data Preprocessing Pipeline

The data underwent comprehensive preprocessing to optimize model performance and ensure consistent data quality.

#### 2.2.1 Feature Preprocessing

**Preprocessing Method**: StandardScaler (Z-score normalization)

```python
# Feature transformation: X_scaled = (X - μ) / σ
# Where μ = mean, σ = standard deviation
X_scaled = (X - X.mean(axis=0)) / X.std(axis=0)
```

**Preprocessing Benefits:**
- **Feature Consistency**: Normalizes different scales and units
- **Algorithm Optimization**: Improves convergence for distance-based methods
- **Numerical Stability**: Prevents overflow/underflow in computations
- **Cross-Validation Integrity**: Separate scaling per fold prevents data leakage

### 2.3 Feature Engineering

### 2.3 Feature Selection and Engineering

#### 2.3.1 Feature Selection Strategy

**Approach**: Comprehensive feature utilization

XGBoost inherently performs feature selection during the training of boosted trees. Key mechanisms include:
- **Greedy Search**: At each split, the algorithm selects the feature and split point that maximize the gain.
- **Regularization**: L1 (Lasso) and L2 (Ridge) regularization penalize complex models, effectively shrinking the coefficients of less important features.
- **Feature Importance Calculation**: XGBoost provides multiple metrics (gain, weight, cover) to score feature relevance automatically.

#### 2.3.2 Feature Engineering Pipeline

**Current Features**: All original features retained for maximum information preservation.
**Categorical Encoding**: Best practice is to one-hot encode categorical features for XGBoost.
**Missing Value Strategy**: XGBoost has a built-in, optimized routine to handle missing values by learning a default direction for them at each split.
**Feature Interaction**: Captured implicitly and explicitly through the tree-based structure of the model.


---

## 3. Hyperparameter Optimization

### 3.1 Hyperparameter Search Space

The optimization process systematically explored a comprehensive parameter space designed to balance model complexity and performance:

| Parameter | Range/Options | Description |
|-----------|---------------|-------------|
| n_estimators | 50-150 (step: 10) | Number of boosting rounds (trees) in the ensemble |
| max_depth | 1-10 (step: 1) | Maximum depth of each tree in the ensemble |
| learning_rate | 0.01-0.3 (log scale) | Step size shrinkage to prevent overfitting |
| subsample | 0.6-1.0 (linear scale) | Fraction of samples used for training each tree |
| colsample_bytree | 0.6-1.0 (linear scale) | Fraction of features used for training each tree |
| colsample_bylevel | 0.6-1.0 (linear scale) | Fraction of features used for each level in each tree |
| reg_alpha | 1e-08-10.0 (log scale) | L1 regularization term on weights (Lasso regularization) |
| reg_lambda | 1e-08-10.0 (log scale) | L2 regularization term on weights (Ridge regularization) |
| min_child_weight | 1-10 (step: 1) | Minimum sum of instance weight needed in a child node |
| gamma | 1e-08-10.0 (log scale) | Minimum loss reduction required to make a split |

### 3.2 Optimization Algorithm and Strategy

**Algorithm**: TPE (Tree-structured Parzen Estimator)
**Total Trials**: 50
**Completed Trials**: 50
**Best Score**: -0.255073

**Optimization Strategy:**
- **Initial Exploration**: 10 random trials for space exploration
- **Exploitation-Exploration Balance**: TPE algorithm balances promising regions with unexplored space
- **Cross-Validation**: Each trial evaluated using stratified k-fold cross-validation
- **Early Stopping**: Poor-performing trials terminated early to improve efficiency

### 3.3 Best Parameters Found

```json
{
  "n_estimators": 70,
  "max_depth": 8,
  "learning_rate": 0.29283225933783363,
  "subsample": 0.8824879580256776,
  "colsample_bytree": 0.8804650381575039,
  "colsample_bylevel": 0.9862778301767895,
  "reg_alpha": 0.0004686094248233635,
  "reg_lambda": 3.841105485827389e-06,
  "min_child_weight": 2,
  "gamma": 1.1415897581582742e-08
}
```

### 3.4 Optimization Convergence

The optimization process completed **50 trials** with the best configuration achieving a cross-validation score of **-0.255073**.

**Key Optimization Insights:**
- **Ensemble Size**: 70 boosting rounds balances performance and computational efficiency
- **Tree Complexity**: Maximum depth of 8 controls model complexity and overfitting
- **Learning Rate**: 0.29283225933783363 provides optimal step size for gradient descent
- **Regularization**: L1=4.69e-04, L2=3.84e-06 prevent overfitting
- **Sampling**: 0.8824879580256776 row sampling and 0.8804650381575039 column sampling for robustness

## 4. Final Model Training

### 4.1 Cross-Validation Training

The final model was trained using 5-fold cross-validation with optimized hyperparameters. Training metrics and validation results were recorded comprehensively.

### 4.2 Training Results

| Metric | Value |
|--------|-------|
### Cross-Validation Performance Metrics

| Metric | Mean ± Std | Min | Max |
|--------|------------|-----|-----|
| MAE | 0.255073 ± 0.027165 | 0.222570 | 0.300124 |
| MSE | 0.099230 ± 0.017944 | 0.072857 | 0.123701 |
| R2 | 0.893990 ± 0.022979 | 0.867491 | 0.925703 |



#### Fold-wise Results

#### Detailed Fold-wise Performance

| Fold | MAE | MSE | R2 |
|------|---------|---------|---------|
| 1 | 0.259896 | 0.099927 | 0.867491 |
| 2 | 0.300124 | 0.123701 | 0.876430 |
| 3 | 0.261043 | 0.087293 | 0.925703 |
| 4 | 0.231732 | 0.112371 | 0.883614 |
| 5 | 0.222570 | 0.072857 | 0.916710 |

#### Statistical Summary

| Metric | Mean | Std Dev | Min | Max | 95% CI |
|--------|------|---------|-----|-----|--------|
| MAE | 0.255073 | 0.027165 | 0.222570 | 0.300124 | [0.231262, 0.278884] |
| MSE | 0.099230 | 0.017944 | 0.072857 | 0.123701 | [0.083501, 0.114959] |
| R2 | 0.893990 | 0.022979 | 0.867491 | 0.925703 | [0.873848, 0.914131] |

### 4.3 Model Performance Visualization

#### Training Performance Analysis

The cross-validation analysis demonstrates the model's predictive performance through scatter plots comparing predicted versus actual values.

<div style="text-align: center; margin: 20px 0;">
    <img src="cross_validation_data/cross_validation_scatter.png" alt="Cross-Validation Scatter Plot" style="max-width: 100%; height: auto; border-radius: 8px; box-shadow: 0 4px 8px rgba(0,0,0,0.1);">
    <p style="font-style: italic; color: #666; margin-top: 10px;">Cross-Validation: Predicted vs Actual Values</p>
</div>


<div style="text-align: center; margin: 20px 0;">
    <img src="cross_validation_data/cross_validation_scatter_normalized.png" alt="Normalized Cross-Validation Scatter Plot" style="max-width: 100%; height: auto; border-radius: 8px; box-shadow: 0 4px 8px rgba(0,0,0,0.1);">
    <p style="font-style: italic; color: #666; margin-top: 10px;">Cross-Validation Results on Normalized Data</p>
</div>


<div style="text-align: center; margin: 20px 0;">
    <img src="cross_validation_data/cross_validation_scatter_original.png" alt="Original Scale Cross-Validation Scatter Plot" style="max-width: 100%; height: auto; border-radius: 8px; box-shadow: 0 4px 8px rgba(0,0,0,0.1);">
    <p style="font-style: italic; color: #666; margin-top: 10px;">Cross-Validation Results on Original Scale</p>
</div>



### 4.4 Feature Importance Analysis

#### Feature Importance Analysis

This analysis employs multiple methodologies to comprehensively evaluate feature importance in the XGBoost model:

**Analysis Methods:**

1. **Built-in Importance (Gain, Cover, Weight)**:
   - **Gain**: The average training loss reduction gained when a feature is used for splitting. It is the most common and relevant metric.
   - **Cover**: The average number of samples affected by splits on this feature.
   - **Weight**: The number of times a feature is used to split the data across all trees.

2. **Permutation Importance**:
   - Model-agnostic method measuring feature contribution to model performance
   - Evaluates performance drop when feature values are randomly shuffled
   - More reliable for correlated features and unbiased feature ranking
   - Computed on out-of-sample data to avoid overfitting

**XGBoost Tree-based Feature Importance:**

| Rank | Feature | Gain | Weight | Cover | Gain % | Weight % |
|------|---------|------|--------|-------|--------|----------|
| 1 | `SiO2` | 0.3715 | 180 | 16.44 | 67.3% | 23.5% |
| 2 | `lignin` | 0.1183 | 164 | 19.16 | 21.4% | 21.4% |
| 3 | `vinyl` | 0.0349 | 233 | 18.33 | 6.3% | 30.4% |
| 4 | `CeO2` | 0.0275 | 189 | 19.59 | 5.0% | 24.7% |


**Permutation Feature Importance:**

| Rank | Feature | Mean Importance | Std Dev | 95% CI | Reliability |
|------|---------|-----------------|---------|--------|-------------|
| 1 | `SiO2` | 1.1440 | 0.1363 | [0.8769, 1.4112] | 🟡 Medium |
| 2 | `lignin` | 0.2516 | 0.0309 | [0.1910, 0.3122] | 🟡 Medium |
| 3 | `vinyl` | 0.0704 | 0.0062 | [0.0582, 0.0825] | 🟢 High |
| 4 | `CeO2` | 0.0449 | 0.0087 | [0.0279, 0.0619] | 🟡 Medium |


**Feature Importance Method Comparison:**

| Feature | XGB Gain Rank | Permutation Rank | Rank Difference | Consistency |
|---------|---------------|------------------|-----------------|-------------|
| `SiO2` | 1 | 1 | 0 | 🟢 Excellent |
| `CeO2` | 4 | 4 | 0 | 🟢 Excellent |
| `lignin` | 2 | 2 | 0 | 🟢 Excellent |
| `vinyl` | 3 | 3 | 0 | 🟢 Excellent |


**Statistical Summary:**

- **Total Features Analyzed**: 4
- **Gain-based Top Feature**: `SiO2` (Gain: 0.3715)
- **Permutation-based Top Feature**: `SiO2` (Importance: 1.1440)

**Method Reliability Assessment:**
- **Average Permutation Std**: 0.0455
- **Method Agreement**: High

**Feature Importance Visualizations:**

![Feature Importance Comparison](feature_importance_comparison.png)

**Method Comparison Plot**: `feature_importance_comparison.png`

![Permutation Feature Importance](feature_importance_permutation.png)

**Permutation Importance Plot**: `feature_importance_permutation.png`

![Tree-based Feature Importance](feature_importance_tree.png)

**Tree-based Importance Plot**: `feature_importance_tree.png`

**Feature Importance Data Files:**

- `feature_importance.csv` - Detailed feature importance scores and statistics

**Statistical Interpretation:**

- **Threshold Selection**: Features with importance > 1/n_features are considered significant
- **Cumulative Importance**: Top features typically capture 80-90% of total importance
- **Stability Assessment**: Low standard deviation in permutation importance indicates reliable features
- **Domain Validation**: Feature rankings should align with domain knowledge and expectations

**Technical Implementation Notes:**

- Tree-based importance computed using XGBoost's `feature_importances_` attribute or `get_score()` method.
- Permutation importance calculated with 10 repetitions for statistical robustness
- Random state fixed for reproducible permutation results
- Analysis performed on validation data to avoid overfitting bias


---

## 5. Model Architecture and Configuration

### 5.1 XGBoost Configuration

The final model uses an XGBoost gradient boosting ensemble with the following specifications:

| Component | Configuration |
|-----------|---------------|
| Booster | gbtree (tree-based model) |

### 5.2 Training Parameters

| Parameter | Value |
|-----------|-------|
| Task Type | Regression |

---

## 6. Conclusions and Future Work

### 6.1 Key Findings

2. **Hyperparameter Optimization**: Systematic optimization improved model performance

### 6.2 Reproducibility

This experiment is fully reproducible using the following artifacts:
- **Cross-Validation Data**: `trained_models\9063132f-77f6-4bff-92d1-075c8280fd57/cross_validation_data/`
- **Feature Importance**: `trained_models\9063132f-77f6-4bff-92d1-075c8280fd57/feature_importance.csv`

### 6.3 Technical Implementation

- **Framework**: XGBoost for gradient boosting implementation, scikit-learn for pipeline integration.
- **Data Processing**: pandas and numpy for data handling.
- **Cross-Validation**: K-fold cross-validation with stratification support for classification.
- **Feature Importance**: Built-in XGBoost feature importance calculation (Gain, Cover, Weight).
- **Serialization**: Joblib or Pickle for model and preprocessor persistence.

---

## Appendix

### A.1 System Information

- **Generation Time**: 2025-07-06 00:42:03
- **Model ID**: `9063132f-77f6-4bff-92d1-075c8280fd57`
- **Training System**: XGBoost MCP Tool
- **Report Version**: 2.1 (XGBoost Enhanced)

### A.2 File Structure

```
9063132f-77f6-4bff-92d1-075c8280fd57/
├── model.joblib
├── preprocessing_pipeline.pkl
├── evaluation_metrics.csv
├── feature_importance.csv
├── optimization_history.csv
├── raw_data.csv
├── feature_importance_comparison.png
├── feature_importance_permutation.png
├── feature_importance_tree.png
├── cross_validation_results.json
├── feature_importance_analysis.json
├── hyperparameter_optimization.json
├── metadata.json
├── preprocessing_info.json
├── training_report.json
├── training_summary.json
├── cross_validation_data/
│   ├── 9063132f-77f6-4bff-92d1-075c8280fd57_cv_predictions_original.csv
│   ├── 9063132f-77f6-4bff-92d1-075c8280fd57_cv_predictions_processed.csv
│   ├── 9063132f-77f6-4bff-92d1-075c8280fd57_cv_scatter_plot.png
│   ├── 9063132f-77f6-4bff-92d1-075c8280fd57_original_data.csv
│   ├── 9063132f-77f6-4bff-92d1-075c8280fd57_preprocessed_data.csv
│   ├── cross_validation_scatter.png
│   ├── cross_validation_scatter_normalized.png
│   ├── cross_validation_scatter_original.png
└── academic_report.md               # This report
```

### A.3 Data Files and JSON Artifacts

The following JSON files contain detailed intermediate data for reproducibility:

- **Feature Importance**: `trained_models\9063132f-77f6-4bff-92d1-075c8280fd57/feature_importance.csv`

---

*This report was automatically generated by the Enhanced XGBoost MCP Tool for academic research and reproducibility purposes.*
