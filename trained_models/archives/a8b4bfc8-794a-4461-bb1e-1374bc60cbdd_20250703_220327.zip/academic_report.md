# XGBoost Training Report

**Generated on:** 2025-07-03 22:03:27  
**Model ID:** `a8b4bfc8-794a-4461-bb1e-1374bc60cbdd`  
**Model Folder:** `trained_models\a8b4bfc8-794a-4461-bb1e-1374bc60cbdd`

## Executive Summary

This report documents a comprehensive XGBoost training experiment conducted for academic research and reproducibility purposes. The experiment involved hyperparameter optimization and cross-validated model training with detailed performance analysis, data validation, and feature importance evaluation.

### Key Results
### 🎯 关键性能指标

- **R²分数 (R² Score):** 0.656019 (±0.112768)
- **平均绝对误差 (Mean Absolute Error):** 0.418971 (±0.087095)
- **均方误差 (Mean Squared Error):** 0.359253 (±0.198541)

- **交叉验证折数:** 5
- **数据集规模:** 192 样本, 13 特征

### ⚙️ 最优超参数

- **n_estimators:** 130
- **max_depth:** 10
- **learning_rate:** 0.15845496563635528
- **subsample:** 0.6940358206507765
- **colsample_bytree:** 0.6522104024027379
- **colsample_bylevel:** 0.649174678854386
- **reg_alpha:** 2.0236817526261996e-08
- **reg_lambda:** 2.621347821124754e-08
- **min_child_weight:** 5
- **gamma:** 0.0002543614811465908

- **训练时间:** 1408.28 秒

---

## 1. Experimental Setup

### 1.1 Dataset Information

| Parameter | Value |
|-----------|-------|
| Data Shape | {'n_samples': 192, 'n_features': 13} |
| Number of Targets | 1 |

### 1.2 Training Configuration

| Parameter | Value |
|-----------|-------|
| Task Type | Regression |

### 1.3 Hardware and Software Environment

- **Python Version:** 3.8+
- **Machine Learning Framework:** XGBoost, scikit-learn
- **Data Processing:** pandas, numpy
- **Hyperparameter Optimization:** Optuna
- **Device:** CPU

---

## 2. Data Processing and Validation

### 2.1 Data Loading and Initial Inspection

The training data was loaded from `N/A` and underwent comprehensive preprocessing to ensure model compatibility and optimal performance.

**Input Features (N/A columns):**
`编号`, `双酚`, `氢化`, `环氧值`, `苯基`, `环己烷`, `连苯基`, `连环己基`, `胺值`, `异丁基`, `异辛基`, `己内酯`, `交联密度`

**Target Variables (1 column):**
`断裂韧性`


### 2.4 Data Quality Assessment

Comprehensive data validation was performed using multiple statistical methods to ensure dataset quality and suitability for machine learning model training. The validation framework employed established statistical techniques for thorough data quality assessment.

#### 2.4.1 Overall Quality Metrics

| Metric | Value | Threshold | Interpretation |
|--------|-------|-----------|----------------|
| Overall Data Quality Score | 30.0/100 | ≥80 (Excellent), ≥60 (Good) | Poor - Significant issues require resolution |
| Quality Level | Poor | - | Categorical assessment |
| Ready for Training | No | Yes | Model training readiness |
| Critical Issues | 20 | 0 | Data integrity problems |
| Warnings | 0 | <5 | Minor data quality concerns |

#### 2.4.2 Validation Methodology and Results

| Check Name | Method Used | Status | Issues Found | Key Findings |
|------------|-------------|--------|-------------|-------------|
| Feature Names | Statistical Analysis | ❌ FAILED | 14 | 14 issues found |
| Data Dimensions | Statistical Analysis | ✅ PASSED | 0 | No issues |
| Target Variable | Statistical Analysis | ✅ PASSED | 0 | No issues |
| Data Leakage | Statistical Analysis | ❌ FAILED | 2 | 2 issues found |
| Sample Balance | Chi-square, Gini coefficient | ✅ PASSED | 0 | Target distribution checked |
| Feature Correlations | Pearson/Spearman/Kendall | ❌ FAILED | 2 | 14 high correlations |
| Multicollinearity Detection | Variance Inflation Factor (VIF) | ❌ FAILED | 2 | 13 high VIF; avg=640.85 |
| Feature Distributions | Shapiro-Wilk, Jarque-Bera, D'Agostino | ✅ PASSED | 21 | 21 distribution issues |


#### 2.4.2.4 Target Variable Distribution Analysis

**Methodology**: For regression tasks, the distribution of the continuous target variable is analyzed using descriptive statistics to identify its central tendency, dispersion, and shape.

**Results**:
- **Outlier Ratio**: 0.52% of target values were identified as outliers using the IQR method.
- **Distribution Shape**: Skewness of 0.903 and Kurtosis of 0.861.

**Target Variable Statistics**:
| Statistic | Value |
|-----------|-------|
| Mean | 1.0433 |
| Standard Deviation | 0.2188 |
| Minimum | 0.6788 |
| 25th Percentile | 0.8810 |
| Median (50th) | 1.0134 |
| 75th Percentile | 1.1589 |
| Maximum | 1.9467 |
| Skewness | 0.9029 |
| Kurtosis | 0.8609 |

**Methodological Implications**: The distribution of the target variable is crucial for regression model performance. Significant skewness or a high number of outliers may suggest the need for target transformation (e.g., log transformation) to improve model stability and accuracy.

#### 2.4.2.1 Feature Correlation Analysis

**Methodology**: Pearson, Spearman, and Kendall correlation coefficients were computed for all feature pairs. The correlation threshold was set at |r| ≥ 0.7.

**Results**: 14 feature pairs exceeded the correlation threshold, indicating potential redundancy in the feature space.

**Feature Classification**:
Continuous Features: 编号, 双酚, 氢化, 苯基, 环己烷, 连苯基, 连环己基, 异丁基, 异辛基, 交联密度
Categorical Features: 环氧值, 胺值, 己内酯
Target Feature: 断裂韧性

**Statistical Findings**:
**Continuous Features vs Continuous Features Correlation Analysis (Pearson Correlation Coefficient)**:

| Feature 1 | Feature 2 | Correlation | Absolute Value |
|-----------|-----------|-------------|----------------|
| 双酚 | 氢化 | -0.9791 | 0.9791 |
| 编号 | 双酚 | -0.8316 | 0.8316 |
| 氢化 | 交联密度 | -0.7706 | 0.7706 |
| 双酚 | 交联密度 | 0.7670 | 0.7670 |
| 编号 | 氢化 | 0.7633 | 0.7633 |
| 异丁基 | 异辛基 | -0.5659 | 0.5659 |
| 编号 | 交联密度 | -0.4182 | 0.4182 |
| 连苯基 | 连环己基 | -0.3291 | 0.3291 |
| 苯基 | 连苯基 | -0.3280 | 0.3280 |
| 环己烷 | 连苯基 | -0.3280 | 0.3280 |


**Continuous Features vs Continuous Features Correlation Analysis (Spearman's Rank Correlation)**:

| Feature 1 | Feature 2 | Correlation | Absolute Value |
|-----------|-----------|-------------|----------------|
| 异丁基 | 异辛基 | -0.8573 | 0.8573 |
| 编号 | 双酚 | -0.8326 | 0.8326 |
| 双酚 | 氢化 | -0.7457 | 0.7457 |
| 编号 | 氢化 | 0.7294 | 0.7294 |
| 氢化 | 交联密度 | -0.7088 | 0.7088 |
| 双酚 | 交联密度 | 0.5286 | 0.5286 |
| 连苯基 | 连环己基 | -0.3243 | 0.3243 |
| 苯基 | 连苯基 | -0.3243 | 0.3243 |
| 环己烷 | 连苯基 | -0.3243 | 0.3243 |
| 苯基 | 连环己基 | -0.3243 | 0.3243 |


**Categorical Features vs Categorical Features Correlation Analysis (Cramér's V Coefficient)**:

| Feature 1 | Feature 2 | Cramér's V | Absolute Value | Strength |
|-----------|-----------|------------|----------------|----------|
| 环氧值 | 己内酯 | 0.2356 | 0.2356 | Weak |
| 胺值 | 己内酯 | 0.1197 | 0.1197 | Very Weak |
| 环氧值 | 胺值 | 0.0641 | 0.0641 | Very Weak |


**Continuous Features vs Categorical Features Correlation Analysis (Correlation Ratio)**:

| Categorical Feature | Continuous Feature | Correlation Ratio | Absolute Value | Strength |
|-------------------|-------------------|-------------------|----------------|----------|
| 环氧值 | 氢化 | 0.9868 | 0.9868 | Large effect (Strong association) |
| 胺值 | 连苯基 | 0.9830 | 0.9830 | Large effect (Strong association) |
| 胺值 | 连环己基 | 0.9814 | 0.9814 | Large effect (Strong association) |
| 胺值 | 苯基 | 0.9750 | 0.9750 | Large effect (Strong association) |
| 胺值 | 环己烷 | 0.9745 | 0.9745 | Large effect (Strong association) |
| 环氧值 | 双酚 | 0.9707 | 0.9707 | Large effect (Strong association) |
| 环氧值 | 编号 | 0.9340 | 0.9340 | Large effect (Strong association) |
| 环氧值 | 交联密度 | 0.7269 | 0.7269 | Large effect (Strong association) |
| 胺值 | 编号 | 0.0460 | 0.0460 | Small effect (Weak association) |
| 胺值 | 交联密度 | 0.0422 | 0.0422 | Small effect (Weak association) |
| 环氧值 | 异丁基 | 0.0410 | 0.0410 | Small effect (Weak association) |
| 己内酯 | 交联密度 | 0.0344 | 0.0344 | Small effect (Weak association) |
| 己内酯 | 氢化 | 0.0338 | 0.0338 | Small effect (Weak association) |
| 己内酯 | 异辛基 | 0.0296 | 0.0296 | Small effect (Weak association) |
| 己内酯 | 异丁基 | 0.0249 | 0.0249 | Small effect (Weak association) |
| 己内酯 | 双酚 | 0.0211 | 0.0211 | Small effect (Weak association) |
| 环氧值 | 异辛基 | 0.0211 | 0.0211 | Small effect (Weak association) |
| 己内酯 | 环己烷 | 0.0149 | 0.0149 | Small effect (Weak association) |
| 环氧值 | 苯基 | 0.0145 | 0.0145 | Small effect (Weak association) |
| 己内酯 | 苯基 | 0.0140 | 0.0140 | Small effect (Weak association) |


**Continuous Features vs Target Variable Correlation Analysis**:

| Feature | Correlation | Method | Absolute Value | Strength |
|---------|-------------|--------|----------------|----------|
| 交联密度 | -0.6038 | pearson | 0.6038 | Moderate |
| 双酚 | -0.4893 | pearson | 0.4893 | Weak |
| 氢化 | 0.4483 | pearson | 0.4483 | Weak |
| 异辛基 | 0.2713 | pearson | 0.2713 | Very Weak |
| 编号 | 0.2511 | pearson | 0.2511 | Very Weak |
| 苯基 | -0.1837 | pearson | 0.1837 | Very Weak |
| 连环己基 | 0.0733 | pearson | 0.0733 | Very Weak |
| 连苯基 | -0.0427 | pearson | 0.0427 | Very Weak |
| 异丁基 | 0.0187 | pearson | 0.0187 | Very Weak |
| 环己烷 | 0.0135 | pearson | 0.0135 | Very Weak |


**Categorical Features vs Target Variable Correlation Analysis**:

| Categorical Feature | Association | Method | Absolute Value | Strength |
|------------------- |-------------|--------|----------------|----------|
| 环氧值 | 0.2957 | correlation_ratio | 0.2957 | Weak |
| 己内酯 | 0.0479 | correlation_ratio | 0.0479 | Very Weak |
| 胺值 | 0.0297 | correlation_ratio | 0.0297 | Very Weak |


**Impact Assessment**: High feature correlation may lead to multicollinearity issues and reduced model interpretability.

#### 2.4.2.2 Multicollinearity Detection

**Methodology**: Variance Inflation Factor (VIF) analysis was conducted using linear regression. VIF values ≥ 5.0 indicate problematic multicollinearity.

**Results**: 
- Average VIF: 640.848
- Maximum VIF: 1000.000
- Features with VIF ≥ 5.0: 13

**Statistical Findings**:
**VIF Scores for All Features**:

| Feature | VIF Score | R² | Interpretation | Status |
|---------|-----------|----|--------------|---------|
| 环氧值 | 1000.0000 | 0.9990 | Severe | ⚠️ HIGH |
| 编号 | 1000.0000 | 0.9990 | Severe | ⚠️ HIGH |
| 双酚 | 1000.0000 | 0.9990 | Severe | ⚠️ HIGH |
| 氢化 | 1000.0000 | 0.9990 | Severe | ⚠️ HIGH |
| 苯基 | 1000.0000 | 0.9990 | Severe | ⚠️ HIGH |
| 环己烷 | 1000.0000 | 0.9990 | Severe | ⚠️ HIGH |
| 连苯基 | 1000.0000 | 0.9990 | Severe | ⚠️ HIGH |
| 连环己基 | 1000.0000 | 0.9990 | Severe | ⚠️ HIGH |
| 胺值 | 253.6729 | 0.9961 | Severe | ⚠️ HIGH |
| 异辛基 | 36.4586 | 0.9726 | Severe | ⚠️ HIGH |
| 异丁基 | 28.6976 | 0.9652 | Severe | ⚠️ HIGH |
| 交联密度 | 6.5561 | 0.8475 | Moderate | ⚠️ MODERATE |
| 己内酯 | 5.6349 | 0.8225 | Moderate | ⚠️ MODERATE |


**Methodological Impact**: Elevated VIF scores suggest linear dependencies between predictors, which may compromise model stability and coefficient interpretation.

#### 2.4.2.3 Feature Distribution Analysis

**Methodology**: 
- Continuous features: Shapiro-Wilk test (n≤5000), Jarque-Bera test (n≥50), D'Agostino test (n≥20) for normality
- Skewness assessment using sample skewness coefficient
- Outlier detection via Interquartile Range (IQR) method
- Categorical features: Gini coefficient, entropy, and class imbalance ratio analysis

**Results**: 0 distribution-related issues identified across 7 continuous and 6 categorical features.

**Continuous Features Statistical Summary**:
| Feature | mean | std | min | max | max | median | Skewness | Kurtosis | Normality | Outliers (%) | Issues |
|---------|----------|---------|----------|---------|----------|---------|----------|-----------|-------------|--------|
| 交联密度 | 2044.076 | 723.444 | 633.728 | 3948.348 | 3948.348 | 2150.012 | 0.043 | -0.554 | No | 0.0% | 0 |
| 双酚 | 0.341 | 0.201 | 0.000 | 0.554 | 0.554 | 0.431 | -1.037 | -0.746 | No | 0.0% | 2 |
| 异丁基 | 0.018 | 0.025 | 0.000 | 0.100 | 0.100 | 0.001 | 1.310 | 0.659 | No | 4.2% | 2 |
| 异辛基 | 0.026 | 0.033 | 0.000 | 0.107 | 0.107 | 0.002 | 0.966 | -0.469 | No | 0.0% | 1 |
| 氢化 | 0.121 | 0.212 | 0.000 | 0.550 | 0.550 | 0.000 | 1.182 | -0.562 | No | 25.0% | 3 |
| 环己烷 | 0.020 | 0.035 | 0.000 | 0.101 | 0.101 | 0.000 | 1.227 | -0.382 | No | 25.0% | 3 |
| 编号 | 933.026 | 559.569 | 5.000 | 1923.000 | 1923.000 | 896.000 | 0.092 | -1.193 | No | 0.0% | 1 |
| 苯基 | 0.019 | 0.033 | 0.000 | 0.094 | 0.094 | 0.000 | 1.225 | -0.391 | No | 25.0% | 6 |
| 连环己基 | 0.039 | 0.068 | 0.000 | 0.196 | 0.196 | 0.000 | 1.202 | -0.479 | No | 25.0% | 3 |
| 连苯基 | 0.037 | 0.065 | 0.000 | 0.185 | 0.185 | 0.000 | 1.197 | -0.501 | No | 25.0% | 3 |

**Continuous Feature Distribution Issues:**
- Feature '编号' significantly deviates from normal distribution
- Feature '双酚' is highly skewed (-1.04)
- Feature '双酚' significantly deviates from normal distribution
- Feature '氢化' is highly skewed (1.18)
- Feature '氢化' has high outlier ratio (25.0%)
- Feature '氢化' significantly deviates from normal distribution
- Feature '苯基' is highly skewed (1.22)
- Feature '苯基' has high outlier ratio (25.0%)
- Feature '苯基' significantly deviates from normal distribution
- Feature '环己烷' is highly skewed (1.23)
- Feature '环己烷' has high outlier ratio (25.0%)
- Feature '环己烷' significantly deviates from normal distribution
- Feature '连苯基' is highly skewed (1.20)
- Feature '连苯基' has high outlier ratio (25.0%)
- Feature '连苯基' significantly deviates from normal distribution
- Feature '连环己基' is highly skewed (1.20)
- Feature '连环己基' has high outlier ratio (25.0%)
- Feature '连环己基' significantly deviates from normal distribution
- Feature '异丁基' is highly skewed (1.31)
- Feature '异丁基' significantly deviates from normal distribution
- Feature '异辛基' significantly deviates from normal distribution


**Categorical Features Statistical Summary**:
| Feature | Classes | Gini Coeff | Imbalance Ratio | Entropy | Issues |
|---------|---------|------------|-----------------|---------|--------|
| distribution_statistics | 0 | 0.000 | 1.0:1 | 0.000 | 0 |
| imbalance_analysis | 0 | 0.000 | 1.0:1 | 0.000 | 0 |
| cardinality_analysis | 0 | 0.000 | 1.0:1 | 0.000 | 0 |


**Distribution Quality Impact**: Feature distributions meet statistical assumptions for machine learning applications.

#### 2.4.2.5 Statistical Summary

**Validation Framework Performance**:
- Total validation checks: 8
- Passed checks: 4 (50.0%)
- Failed checks: 4

**Data Quality Confidence**: Based on the comprehensive validation framework, the dataset demonstrates low statistical reliability for machine learning applications.

#### 2.4.3 Data Quality Issues and Impact Assessment

**Critical Issues Identified:**

- Invalid feature name after normalization: '编号'
- Invalid feature name after normalization: '双酚'
- Invalid feature name after normalization: '氢化'
- Invalid feature name after normalization: '环氧值'
- Invalid feature name after normalization: '苯基'
- Invalid feature name after normalization: '环己烷'
- Invalid feature name after normalization: '连苯基'
- Invalid feature name after normalization: '连环己基'
- Invalid feature name after normalization: '胺值'
- Invalid feature name after normalization: '异丁基'
- Invalid feature name after normalization: '异辛基'
- Invalid feature name after normalization: '己内酯'

**Data Quality Recommendations:**

1. Consider target transformation for heavily skewed targets
2. Address multicollinearity through feature selection or regularization
3. Investigate high correlations and consider feature selection
4. Remove or investigate highly correlated features for potential data leakage
5. Resolve multicollinearity using VIF-guided feature selection or regularization


#### 2.4.4 Academic and Methodological Implications

The data validation results indicate that the dataset does not meet the quality standards required for academic machine learning research. Poor data quality may compromise experimental validity. Significant preprocessing and quality improvements are recommended before publication.

**Reproducibility Impact**: Low reproducibility confidence due to data quality issues. Preprocessing standardization required for reliable replication.


### 2.2 Data Preprocessing Pipeline

The data underwent comprehensive preprocessing to optimize model performance and ensure consistent data quality.

#### 2.2.1 Feature Preprocessing

**Preprocessing Method**: StandardScaler (Z-score normalization)

```python
# Feature transformation: X_scaled = (X - μ) / σ
# Where μ = mean, σ = standard deviation
X_scaled = (X - X.mean(axis=0)) / X.std(axis=0)
```

**Preprocessing Benefits:**
- **Feature Consistency**: Normalizes different scales and units
- **Algorithm Optimization**: Improves convergence for distance-based methods
- **Numerical Stability**: Prevents overflow/underflow in computations
- **Cross-Validation Integrity**: Separate scaling per fold prevents data leakage

### 2.3 Feature Engineering

### 2.3 Feature Selection and Engineering

#### 2.3.1 Feature Selection Strategy

**Approach**: Comprehensive feature utilization

XGBoost inherently performs feature selection during the training of boosted trees. Key mechanisms include:
- **Greedy Search**: At each split, the algorithm selects the feature and split point that maximize the gain.
- **Regularization**: L1 (Lasso) and L2 (Ridge) regularization penalize complex models, effectively shrinking the coefficients of less important features.
- **Feature Importance Calculation**: XGBoost provides multiple metrics (gain, weight, cover) to score feature relevance automatically.

#### 2.3.2 Feature Engineering Pipeline

**Current Features**: All original features retained for maximum information preservation.
**Categorical Encoding**: Best practice is to one-hot encode categorical features for XGBoost.
**Missing Value Strategy**: XGBoost has a built-in, optimized routine to handle missing values by learning a default direction for them at each split.
**Feature Interaction**: Captured implicitly and explicitly through the tree-based structure of the model.


---

## 3. Hyperparameter Optimization

### 3.1 Hyperparameter Search Space

The optimization process systematically explored a comprehensive parameter space designed to balance model complexity and performance:

| Parameter | Range/Options | Description |
|-----------|---------------|-------------|
| n_estimators | 50-150 (step: 10) | Number of boosting rounds (trees) in the ensemble |
| max_depth | 1-10 (step: 1) | Maximum depth of each tree in the ensemble |
| learning_rate | 0.01-0.3 (log scale) | Step size shrinkage to prevent overfitting |
| subsample | 0.6-1.0 (linear scale) | Fraction of samples used for training each tree |
| colsample_bytree | 0.6-1.0 (linear scale) | Fraction of features used for training each tree |
| colsample_bylevel | 0.6-1.0 (linear scale) | Fraction of features used for each level in each tree |
| reg_alpha | 1e-08-10.0 (log scale) | L1 regularization term on weights (Lasso regularization) |
| reg_lambda | 1e-08-10.0 (log scale) | L2 regularization term on weights (Ridge regularization) |
| min_child_weight | 1-10 (step: 1) | Minimum sum of instance weight needed in a child node |
| gamma | 1e-08-10.0 (log scale) | Minimum loss reduction required to make a split |

### 3.2 Optimization Algorithm and Strategy

**Algorithm**: TPE (Tree-structured Parzen Estimator)
**Total Trials**: 200
**Completed Trials**: 200
**Best Score**: -0.418971

**Optimization Strategy:**
- **Initial Exploration**: 10 random trials for space exploration
- **Exploitation-Exploration Balance**: TPE algorithm balances promising regions with unexplored space
- **Cross-Validation**: Each trial evaluated using stratified k-fold cross-validation
- **Early Stopping**: Poor-performing trials terminated early to improve efficiency

### 3.3 Best Parameters Found

```json
{
  "n_estimators": 130,
  "max_depth": 10,
  "learning_rate": 0.15845496563635528,
  "subsample": 0.6940358206507765,
  "colsample_bytree": 0.6522104024027379,
  "colsample_bylevel": 0.649174678854386,
  "reg_alpha": 2.0236817526261996e-08,
  "reg_lambda": 2.621347821124754e-08,
  "min_child_weight": 5,
  "gamma": 0.0002543614811465908
}
```

### 3.4 Optimization Convergence

The optimization process completed **200 trials** with the best configuration achieving a cross-validation score of **-0.418971**.

**Key Optimization Insights:**
- **Ensemble Size**: 130 boosting rounds balances performance and computational efficiency
- **Tree Complexity**: Maximum depth of 10 controls model complexity and overfitting
- **Learning Rate**: 0.15845496563635528 provides optimal step size for gradient descent
- **Regularization**: L1=2.02e-08, L2=2.62e-08 prevent overfitting
- **Sampling**: 0.6940358206507765 row sampling and 0.6522104024027379 column sampling for robustness

## 4. Final Model Training

### 4.1 Cross-Validation Training

The final model was trained using 5-fold cross-validation with optimized hyperparameters. Training metrics and validation results were recorded comprehensively.

### 4.2 Training Results

| Metric | Value |
|--------|-------|
### Cross-Validation Performance Metrics

| Metric | Mean ± Std | Min | Max |
|--------|------------|-----|-----|
| MAE | 0.418971 ± 0.087095 | 0.304994 | 0.547284 |
| MSE | 0.359253 ± 0.198541 | 0.181614 | 0.714748 |
| R2 | 0.656019 ± 0.112768 | 0.520200 | 0.795815 |



#### Fold-wise Results

#### Detailed Fold-wise Performance

| Fold | MAE | MSE | R2 |
|------|---------|---------|---------|
| 1 | 0.363704 | 0.210407 | 0.754061 |
| 2 | 0.304994 | 0.181614 | 0.795815 |
| 3 | 0.487293 | 0.435809 | 0.531601 |
| 4 | 0.391582 | 0.253688 | 0.678416 |
| 5 | 0.547284 | 0.714748 | 0.520200 |

#### Statistical Summary

| Metric | Mean | Std Dev | Min | Max | 95% CI |
|--------|------|---------|-----|-----|--------|
| MAE | 0.418971 | 0.087095 | 0.304994 | 0.547284 | [0.342629, 0.495313] |
| MSE | 0.359253 | 0.198541 | 0.181614 | 0.714748 | [0.185224, 0.533282] |
| R2 | 0.656019 | 0.112768 | 0.520200 | 0.795815 | [0.557173, 0.754864] |

### 4.3 Model Performance Visualization

#### Training Performance Analysis

The cross-validation analysis demonstrates the model's predictive performance through scatter plots comparing predicted versus actual values.

<div style="text-align: center; margin: 20px 0;">
    <img src="cross_validation_data/cross_validation_scatter.png" alt="Cross-Validation Scatter Plot" style="max-width: 100%; height: auto; border-radius: 8px; box-shadow: 0 4px 8px rgba(0,0,0,0.1);">
    <p style="font-style: italic; color: #666; margin-top: 10px;">Cross-Validation: Predicted vs Actual Values</p>
</div>


<div style="text-align: center; margin: 20px 0;">
    <img src="cross_validation_data/cross_validation_scatter_normalized.png" alt="Normalized Cross-Validation Scatter Plot" style="max-width: 100%; height: auto; border-radius: 8px; box-shadow: 0 4px 8px rgba(0,0,0,0.1);">
    <p style="font-style: italic; color: #666; margin-top: 10px;">Cross-Validation Results on Normalized Data</p>
</div>


<div style="text-align: center; margin: 20px 0;">
    <img src="cross_validation_data/cross_validation_scatter_original.png" alt="Original Scale Cross-Validation Scatter Plot" style="max-width: 100%; height: auto; border-radius: 8px; box-shadow: 0 4px 8px rgba(0,0,0,0.1);">
    <p style="font-style: italic; color: #666; margin-top: 10px;">Cross-Validation Results on Original Scale</p>
</div>



### 4.4 Feature Importance Analysis

#### Feature Importance Analysis

This analysis employs multiple methodologies to comprehensively evaluate feature importance in the XGBoost model:

**Analysis Methods:**

1. **Built-in Importance (Gain, Cover, Weight)**:
   - **Gain**: The average training loss reduction gained when a feature is used for splitting. It is the most common and relevant metric.
   - **Cover**: The average number of samples affected by splits on this feature.
   - **Weight**: The number of times a feature is used to split the data across all trees.

2. **Permutation Importance**:
   - Model-agnostic method measuring feature contribution to model performance
   - Evaluates performance drop when feature values are randomly shuffled
   - More reliable for correlated features and unbiased feature ranking
   - Computed on out-of-sample data to avoid overfitting

**XGBoost Tree-based Feature Importance:**

| Rank | Feature | Gain | Weight | Cover | Gain % | Weight % |
|------|---------|------|--------|-------|--------|----------|
| 1 | `氢化` | 0.5948 | 75 | 55.81 | 19.9% | 3.4% |
| 2 | `编号` | 0.3967 | 405 | 41.81 | 13.3% | 18.4% |
| 3 | `异丁基` | 0.3340 | 193 | 57.27 | 11.2% | 8.8% |
| 4 | `交联密度` | 0.3124 | 382 | 41.90 | 10.5% | 17.3% |
| 5 | `异辛基` | 0.2734 | 177 | 46.46 | 9.2% | 8.0% |
| 6 | `己内酯` | 0.1966 | 157 | 26.96 | 6.6% | 7.1% |
| 7 | `环氧值` | 0.1893 | 91 | 37.98 | 6.3% | 4.1% |
| 8 | `双酚` | 0.1715 | 269 | 41.48 | 5.7% | 12.2% |
| 9 | `苯基` | 0.1410 | 92 | 47.47 | 4.7% | 4.2% |
| 10 | `连苯基` | 0.1286 | 74 | 38.61 | 4.3% | 3.4% |
| 11 | `环己烷` | 0.0941 | 90 | 42.19 | 3.2% | 4.1% |
| 12 | `连环己基` | 0.0813 | 81 | 42.89 | 2.7% | 3.7% |
| 13 | `胺值` | 0.0723 | 118 | 27.77 | 2.4% | 5.4% |


**Permutation Feature Importance:**

| Rank | Feature | Mean Importance | Std Dev | 95% CI | Reliability |
|------|---------|-----------------|---------|--------|-------------|
| 1 | `交联密度` | 0.3476 | 0.0322 | [0.2845, 0.4108] | 🟢 High |
| 2 | `编号` | 0.1966 | 0.0180 | [0.1613, 0.2319] | 🟢 High |
| 3 | `异丁基` | 0.1728 | 0.0101 | [0.1530, 0.1926] | 🟢 High |
| 4 | `异辛基` | 0.1014 | 0.0114 | [0.0790, 0.1237] | 🟡 Medium |
| 5 | `双酚` | 0.0690 | 0.0088 | [0.0518, 0.0862] | 🟡 Medium |
| 6 | `氢化` | 0.0637 | 0.0057 | [0.0525, 0.0749] | 🟢 High |
| 7 | `己内酯` | 0.0631 | 0.0024 | [0.0584, 0.0678] | 🟢 High |
| 8 | `苯基` | 0.0262 | 0.0022 | [0.0220, 0.0305] | 🟢 High |
| 9 | `环氧值` | 0.0222 | 0.0032 | [0.0159, 0.0285] | 🟡 Medium |
| 10 | `连苯基` | 0.0139 | 0.0014 | [0.0113, 0.0166] | 🟢 High |
| 11 | `连环己基` | 0.0126 | 0.0012 | [0.0103, 0.0150] | 🟢 High |
| 12 | `环己烷` | 0.0109 | 0.0007 | [0.0095, 0.0122] | 🟢 High |
| 13 | `胺值` | 0.0092 | 0.0005 | [0.0082, 0.0102] | 🟢 High |


**Feature Importance Method Comparison:**

| Feature | XGB Gain Rank | Permutation Rank | Rank Difference | Consistency |
|---------|---------------|------------------|-----------------|-------------|
| `编号` | 2 | 2 | 0 | 🟢 Excellent |
| `双酚` | 8 | 5 | 3 | 🔴 Poor |
| `氢化` | 1 | 6 | 5 | 🔴 Poor |
| `环氧值` | 7 | 9 | 2 | 🟡 Good |
| `苯基` | 9 | 8 | 1 | 🟢 Excellent |
| `环己烷` | 11 | 12 | 1 | 🟢 Excellent |
| `连苯基` | 10 | 10 | 0 | 🟢 Excellent |
| `连环己基` | 12 | 11 | 1 | 🟢 Excellent |
| `胺值` | 13 | 13 | 0 | 🟢 Excellent |
| `异丁基` | 3 | 3 | 0 | 🟢 Excellent |
| `异辛基` | 5 | 4 | 1 | 🟢 Excellent |
| `己内酯` | 6 | 7 | 1 | 🟢 Excellent |
| `交联密度` | 4 | 1 | 3 | 🔴 Poor |


**Statistical Summary:**

- **Total Features Analyzed**: 13
- **Gain-based Top Feature**: `氢化` (Gain: 0.5948)
- **Permutation-based Top Feature**: `交联密度` (Importance: 0.3476)

**Method Reliability Assessment:**
- **Average Permutation Std**: 0.0075
- **Method Agreement**: High

**Feature Importance Visualizations:**

![Feature Importance Comparison](feature_importance_comparison.png)

**Method Comparison Plot**: `feature_importance_comparison.png`

![Permutation Feature Importance](feature_importance_permutation.png)

**Permutation Importance Plot**: `feature_importance_permutation.png`

![Tree-based Feature Importance](feature_importance_tree.png)

**Tree-based Importance Plot**: `feature_importance_tree.png`

**Feature Importance Data Files:**

- `feature_importance.csv` - Detailed feature importance scores and statistics

**Statistical Interpretation:**

- **Threshold Selection**: Features with importance > 1/n_features are considered significant
- **Cumulative Importance**: Top features typically capture 80-90% of total importance
- **Stability Assessment**: Low standard deviation in permutation importance indicates reliable features
- **Domain Validation**: Feature rankings should align with domain knowledge and expectations

**Technical Implementation Notes:**

- Tree-based importance computed using XGBoost's `feature_importances_` attribute or `get_score()` method.
- Permutation importance calculated with 10 repetitions for statistical robustness
- Random state fixed for reproducible permutation results
- Analysis performed on validation data to avoid overfitting bias


---

## 5. Model Architecture and Configuration

### 5.1 XGBoost Configuration

The final model uses an XGBoost gradient boosting ensemble with the following specifications:

| Component | Configuration |
|-----------|---------------|
| Booster | gbtree (tree-based model) |

### 5.2 Training Parameters

| Parameter | Value |
|-----------|-------|
| Task Type | Regression |

---

## 6. Conclusions and Future Work

### 6.1 Key Findings

2. **Hyperparameter Optimization**: Systematic optimization improved model performance

### 6.2 Reproducibility

This experiment is fully reproducible using the following artifacts:
- **Cross-Validation Data**: `trained_models\a8b4bfc8-794a-4461-bb1e-1374bc60cbdd/cross_validation_data/`
- **Feature Importance**: `trained_models\a8b4bfc8-794a-4461-bb1e-1374bc60cbdd/feature_importance.csv`

### 6.3 Technical Implementation

- **Framework**: XGBoost for gradient boosting implementation, scikit-learn for pipeline integration.
- **Data Processing**: pandas and numpy for data handling.
- **Cross-Validation**: K-fold cross-validation with stratification support for classification.
- **Feature Importance**: Built-in XGBoost feature importance calculation (Gain, Cover, Weight).
- **Serialization**: Joblib or Pickle for model and preprocessor persistence.

---

## Appendix

### A.1 System Information

- **Generation Time**: 2025-07-03 22:03:27
- **Model ID**: `a8b4bfc8-794a-4461-bb1e-1374bc60cbdd`
- **Training System**: XGBoost MCP Tool
- **Report Version**: 2.1 (XGBoost Enhanced)

### A.2 File Structure

```
a8b4bfc8-794a-4461-bb1e-1374bc60cbdd/
├── model.joblib
├── preprocessing_pipeline.pkl
├── evaluation_metrics.csv
├── feature_importance.csv
├── optimization_history.csv
├── raw_data.csv
├── categorical_cramers_v_correlation.png
├── categorical_feature_cardinality.png
├── categorical_feature_distributions.png
├── categorical_vif_details.png
├── continuous_feature_distributions.png
├── continuous_feature_normality.png
├── continuous_feature_outliers.png
├── continuous_feature_violin_plots.png
├── continuous_pearson_correlation.png
├── continuous_spearman_correlation.png
├── encoding_strategy_summary.png
├── feature_importance_comparison.png
├── feature_importance_permutation.png
├── feature_importance_tree.png
├── feature_target_categorical_association.png
├── feature_target_continuous_correlation.png
├── mixed_correlation_ratio.png
├── vif_scores.png
├── vif_threshold_analysis.png
├── cross_validation_results.json
├── data_validation_report.json
├── feature_importance_analysis.json
├── hyperparameter_optimization.json
├── metadata.json
├── preprocessing_info.json
├── training_report.json
├── training_summary.json
├── cross_validation_data/
│   ├── a8b4bfc8-794a-4461-bb1e-1374bc60cbdd_cv_predictions_original.csv
│   ├── a8b4bfc8-794a-4461-bb1e-1374bc60cbdd_cv_predictions_processed.csv
│   ├── a8b4bfc8-794a-4461-bb1e-1374bc60cbdd_cv_scatter_plot.png
│   ├── a8b4bfc8-794a-4461-bb1e-1374bc60cbdd_original_data.csv
│   ├── a8b4bfc8-794a-4461-bb1e-1374bc60cbdd_preprocessed_data.csv
│   ├── cross_validation_scatter.png
│   ├── cross_validation_scatter_normalized.png
│   ├── cross_validation_scatter_original.png
└── academic_report.md               # This report
```

### A.3 Data Files and JSON Artifacts

The following JSON files contain detailed intermediate data for reproducibility:

- **Feature Importance**: `trained_models\a8b4bfc8-794a-4461-bb1e-1374bc60cbdd/feature_importance.csv`

---

*This report was automatically generated by the Enhanced XGBoost MCP Tool for academic research and reproducibility purposes.*
